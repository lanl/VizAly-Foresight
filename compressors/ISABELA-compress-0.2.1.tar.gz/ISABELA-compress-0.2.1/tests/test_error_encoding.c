#include <stdio.h>
#include <error.h>

int test_multilevel_error_encoding ()
{
    int i = 0;

    double original[] = {5192.2913, 499.2, 85.7, -8.51, 2.312};
    double approximate[] = {5195.23, 49.2, 1.28, -928.51, 2.312};

    int original_output[] = {0};
    int output[] = {};

    return 1;
}

int main (int argc, char *argv [])
{
    if (test_multilevel_error_encoding () != 1) {
        return -1;
    }

    return 1;
}
