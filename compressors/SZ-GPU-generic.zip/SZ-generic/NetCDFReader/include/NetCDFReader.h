#include "netcdf.h"

int netcdfReader(void*, char*, char*, int);
